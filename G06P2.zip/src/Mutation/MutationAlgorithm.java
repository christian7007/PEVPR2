package Mutation;

import Models.Chromosome;

public interface MutationAlgorithm {
	
	public void mutation(Chromosome chromosome);
}
