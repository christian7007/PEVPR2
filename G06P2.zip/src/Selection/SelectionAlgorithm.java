package Selection;

import Models.Population;

/**
 * 
 * @author al3x_hh
 *
 */
public interface SelectionAlgorithm {
	
	/**
	 * 
	 * @return
	 */
	public void selection(Population population);
}
